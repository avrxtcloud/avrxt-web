# Security Policy

If you discover a security vulnerability, do NOT open a public issue.

Please report it privately to:
security@avrxt.in
